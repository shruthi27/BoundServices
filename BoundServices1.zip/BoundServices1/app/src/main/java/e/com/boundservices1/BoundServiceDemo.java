package e.com.boundservices1;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.widget.Toast;

public class BoundServiceDemo extends Service {
    public BoundServiceDemo() {
    }
     IBinder iBinder = new DemoBinder();

    @Override
    public IBinder onBind(Intent intent) {
        Toast.makeText(BoundServiceDemo.this,"Service Bind",Toast.LENGTH_SHORT).show();
        return iBinder;

    }
    class DemoBinder extends Binder{
        public BoundServiceDemo getServiceInstance(){
            return BoundServiceDemo.this;

        }
    }
    public void showMessages(String message){
        Toast.makeText(BoundServiceDemo.this,"Message :" +message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Toast.makeText(BoundServiceDemo.this,"Service unbind", Toast.LENGTH_SHORT).show();
        return super.onUnbind(intent);
    }
}

