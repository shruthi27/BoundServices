package e.com.boundservices1;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button buttonBind,buttonUnbind;
    BoundServiceDemo boundServiceDemo;
    boolean isBind;
    ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            BoundServiceDemo.DemoBinder demoBinder = (BoundServiceDemo.DemoBinder)service;
            boundServiceDemo = demoBinder.getServiceInstance();
            boundServiceDemo.showMessages("welcome to Bound Service");
            isBind = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
           isBind = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonBind = (Button)findViewById(R.id.Boundservice);
        buttonUnbind = (Button)findViewById(R.id.unboundservice);
        buttonBind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,BoundServiceDemo.class);
                 bindService(intent,serviceConnection,BIND_AUTO_CREATE);
            }

        });
        buttonUnbind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isBind){
                    unbindService(serviceConnection);
                    isBind = false;
                }
            }
        });
    }
}
